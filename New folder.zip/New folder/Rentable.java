
public interface Rentable {

    void rent(Customer customer, int days);  // Method for the renting of vehicle

    void returnVehicle();                   // Method to Return a rented vehicle
}

